extends CharacterBody3D
# 玩家：移动/重力/跳跃/开镜/射击/换弹/生命

signal died

const GRAVITY := 20.0
const FONT = preload("res://fonts/ui.otf")

var move_dir := Vector2.ZERO
var yaw := 0.0
var pitch := 0.0
var hp := 100.0
var max_hp := 100.0

var ammo := 30
var mag := 30
var reloading := false
var reload_t := 0.0
var firing := false
var fire_t := 0.0
var ads_on := false
var ads_t := 0.0
var bloom := 0.0
var recoil := 0.0
var kick := 0.0
var muzzle_t := 0.0

var cam: Camera3D
var gun_root: Node3D
var muzzle: OmniLight3D


func _ready() -> void:
        var cs := CollisionShape3D.new()
        var shape := CapsuleShape3D.new()
        shape.radius = 0.35
        shape.height = 1.8
        cs.shape = shape
        cs.position = Vector3(0, 0.9, 0)
        add_child(cs)

        cam = Camera3D.new()
        cam.position = Vector3(0, 1.55, 0)
        cam.fov = 75.0
        cam.current = true
        add_child(cam)

        gun_root = Node3D.new()
        cam.add_child(gun_root)
        var dark := StandardMaterial3D.new()
        dark.albedo_color = Color(0.16, 0.17, 0.19)
        dark.roughness = 0.45
        var mid := StandardMaterial3D.new()
        mid.albedo_color = Color(0.3, 0.31, 0.33)
        mid.roughness = 0.6
        _gun_box(Vector3(0.075, 0.1, 0.5), Vector3.ZERO, dark)                       # 机匣
        _gun_box(Vector3(0.06, 0.07, 0.2), Vector3(0, -0.005, -0.32), mid)           # 护木
        _gun_box(Vector3(0.045, 0.14, 0.06), Vector3(0, -0.11, -0.05), mid)          # 弹匣
        _gun_box(Vector3(0.06, 0.08, 0.16), Vector3(0, -0.01, 0.32), mid)            # 枪托
        _gun_box(Vector3(0.012, 0.05, 0.012), Vector3(0, 0.07, -0.4), dark)          # 准星
        _gun_box(Vector3(0.04, 0.045, 0.04), Vector3(0, 0.075, 0.1), dark)           # 照门
        muzzle = OmniLight3D.new()
        muzzle.light_color = Color(1, 0.65, 0.25)
        muzzle.omni_range = 6.0
        muzzle.position = Vector3(0, 0.02, -0.55)
        muzzle.light_energy = 0.0
        gun_root.add_child(muzzle)
        gun_root.position = Vector3(0.26, -0.24, -0.5)


func _gun_box(size: Vector3, pos: Vector3, m: Material) -> void:
        var mi := MeshInstance3D.new()
        var mesh := BoxMesh.new()
        mesh.size = size
        mi.mesh = mesh
        mi.material_override = m
        mi.position = pos
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        gun_root.add_child(mi)


func take_hit(dmg: float) -> void:
        if hp <= 0:
                return
        hp = maxf(hp - dmg, 0.0)
        if hp <= 0:
                died.emit()


func heal(n: float) -> void:
        hp = minf(hp + n, max_hp)


func try_jump() -> void:
        if hp > 0 and is_on_floor():
                velocity.y = 7.2


func set_ads(on: bool) -> void:
        ads_on = on


func start_reload() -> void:
        if reloading or ammo == mag or hp <= 0:
                return
        reloading = true
        reload_t = 0.0


func shoot() -> void:
        ammo -= 1
        fire_t = 0.105
        muzzle_t = 0.045
        recoil += (0.013 + randf() * 0.006) * (0.65 if ads_on else 1.0)
        yaw += randf_range(-0.002, 0.002)
        kick = 1.0
        bloom = minf(bloom + 0.16, 1.0)
        var spread := (0.0025 if ads_on else 0.02) + bloom * (0.005 if ads_on else 0.026) \
                + Vector2(velocity.x, velocity.z).length() * 0.004
        var dir := -cam.global_transform.basis.z
        dir += cam.global_transform.basis.x * randf_range(-spread, spread)
        dir += cam.global_transform.basis.y * randf_range(-spread, spread)
        dir = dir.normalized()
        var from := cam.global_position
        var q := PhysicsRayQueryParameters3D.create(from, from + dir * 200.0, 0xFFFFFFFF, [get_rid()])
        var hit := get_world_3d().direct_space_state.intersect_ray(q)
        if hit.is_empty():
                return
        var col = hit.collider
        if col != null and col.is_in_group("enemies"):
                var head: bool = hit.position.y > col.global_position.y + 1.55
                col.take_damage(88 if head else 40, hit.position, head)


func _physics_process(dt: float) -> void:
        if hp <= 0:
                return
        # 视角
        rotation.y = yaw
        cam.rotation.x = pitch + recoil
        # 重力 + 移动
        if not is_on_floor():
                velocity.y -= GRAVITY * dt
        var f := -move_dir.y
        var s := move_dir.x
        var spd := 6.0 * (0.55 if ads_on else 1.0)
        var fwd := Vector3(-sin(yaw), 0, -cos(yaw))
        var right := Vector3(cos(yaw), 0, -sin(yaw))
        velocity.x = (fwd.x * f + right.x * s) * spd
        velocity.z = (fwd.z * f + right.z * s) * spd
        move_and_slide()
        # 开火 / 换弹
        fire_t -= dt
        if firing and not reloading and fire_t <= 0 and ammo > 0:
                shoot()
        if ammo <= 0 and not reloading:
                start_reload()
        if reloading:
                reload_t += dt
                if reload_t >= 1.5:
                        reloading = false
                        ammo = mag
        # 后坐力/扩散/枪口 衰减
        recoil -= recoil * minf(6.0 * dt, 0.9)
        bloom = maxf(bloom - dt * 1.1, 0.0)
        kick = maxf(kick - dt * 6.0, 0.0)
        muzzle_t -= dt
        muzzle.light_energy = 3.0 if muzzle_t > 0 else 0.0
        # 开镜插值
        ads_t += ((1.0 if ads_on else 0.0) - ads_t) * minf(dt * 9.0, 1.0)
        cam.fov = lerpf(75.0, 48.0, ads_t)
        # 枪位姿（腰射/机瞄/换弹下垂/后坐kick）
        var hip := Vector3(0.26, -0.24, -0.5)
        var ads_pos := Vector3(0, -0.072, -0.38)
        var target: Vector3 = hip.lerp(ads_pos, ads_t) + Vector3(0, 0, kick * 0.05)
        gun_root.position = gun_root.position.lerp(target, minf(dt * 14.0, 1.0))
        var target_rot := (-0.55 if reloading else kick * 0.08)
        gun_root.rotation.x = lerpf(gun_root.rotation.x, target_rot, minf(dt * 12.0, 1.0))
