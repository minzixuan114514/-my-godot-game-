extends Node3D
# 枪火风暴3D · 主控：世界搭建 / 触屏输入 / 波次管理 / HUD

const PlayerScript = preload("res://scripts/player.gd")
const EnemyScript = preload("res://scripts/enemy.gd")
const FONT = preload("res://fonts/ui.otf")

const SPAWN_POINTS = [
        Vector2(0, -22), Vector2(0, 22), Vector2(-22, 0), Vector2(22, 0),
        Vector2(-17, -17), Vector2(17, 17), Vector2(-17, 17), Vector2(17, -17),
]

var player
var state := "playing"          # playing / dead
var kills := 0
var wave := 0
var to_spawn := 0
var spawn_timer := 0.0
var wave_clear_t := -1.0
var prev_hp := 100.0
var hurt_a := 0.0
var wave_tip_t := 0.0
var medkits: Array = []          # [{node, t, life}]

# 触屏输入
var joy_id := -1
var joy_center := Vector2.ZERO
var joy_vec := Vector2.ZERO
var look_id := -1
var look_last := Vector2.ZERO
var fire_look_id := -1          # 开火键上的手指也能转视角
var fire_look_last := Vector2.ZERO

# 设置
var gyro_on := false
var sens_mult := 1.0
var btn_settings: Button
var settings_panel: Panel
var chk_gyro: CheckButton
var slider_sens: HSlider
var sens_lbl: Label

# UI 引用
var hud: Control
var hp_bar: ProgressBar
var info_label: Label
var ammo_label: Label
var reload_tip: Label
var wave_tip: Label
var hurt_rect: ColorRect
var btn_fire: Button
var btn_jump: Button
var btn_ads: Button
var btn_reload: Button
var joy_base: Panel
var joy_knob: Panel
var death_ui: Control
var death_stats: Label


func _ready() -> void:
        randomize()
        _load_settings()
        _setup_environment()
        _setup_map()
        _setup_player()
        _setup_ui()
        start_wave(1)


# ---------------- 环境 ----------------
func _setup_environment() -> void:
        var env := Environment.new()
        env.background_mode = Environment.BG_SKY
        var sky := Sky.new()
        var sm := ProceduralSkyMaterial.new()
        sm.sky_top_color = Color(0.22, 0.5, 0.82)
        sm.sky_horizon_color = Color(0.74, 0.8, 0.88)
        sm.ground_bottom_color = Color(0.28, 0.27, 0.26)
        sm.ground_horizon_color = Color(0.74, 0.8, 0.88)
        sky.sky_material = sm
        env.sky = sky
        env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
        env.fog_enabled = true
        env.fog_density = 0.006
        env.fog_light_color = Color(0.75, 0.78, 0.82)
        var we := WorldEnvironment.new()
        we.environment = env
        add_child(we)
        var sun := DirectionalLight3D.new()
        sun.rotation = Vector3(deg_to_rad(-52), deg_to_rad(28), 0)
        sun.light_energy = 1.3
        sun.shadow_enabled = true
        add_child(sun)


# ---------------- 地图 ----------------
func _mk_mat(c: Color, rough := 1.0) -> StandardMaterial3D:
        var m := StandardMaterial3D.new()
        m.albedo_color = c
        m.roughness = rough
        return m


func add_box(pos: Vector3, size: Vector3, m: Material, ry := 0.0) -> void:
        var body := StaticBody3D.new()
        var mi := MeshInstance3D.new()
        var mesh := BoxMesh.new()
        mesh.size = size
        mi.mesh = mesh
        mi.material_override = m
        mi.position = pos
        mi.rotation.y = ry
        body.add_child(mi)
        var cs := CollisionShape3D.new()
        var shape := BoxShape3D.new()
        shape.size = size
        cs.shape = shape
        cs.position = pos
        cs.rotation.y = ry
        body.add_child(cs)
        add_child(body)


func _setup_map() -> void:
        # 地面
        add_box(Vector3(0, -0.1, 0), Vector3(56, 0.2, 56), _mk_mat(Color(0.76, 0.68, 0.52)))
        # 围墙 × 4
        var wall := _mk_mat(Color(0.55, 0.42, 0.36))
        add_box(Vector3(0, 1.6, -26), Vector3(54, 3.2, 1), wall)
        add_box(Vector3(0, 1.6, 26), Vector3(54, 3.2, 1), wall)
        add_box(Vector3(-26, 1.6, 0), Vector3(1, 3.2, 54), wall)
        add_box(Vector3(26, 1.6, 0), Vector3(1, 3.2, 54), wall)
        # 中央废墟（三面墙，东侧留口）
        add_box(Vector3(0, 1.3, -4), Vector3(10, 2.6, 0.6), wall)
        add_box(Vector3(-4.7, 1.3, -0.5), Vector3(0.6, 2.6, 7), wall)
        add_box(Vector3(4.7, 1.0, 1.5), Vector3(0.6, 2.0, 4), wall)
        # 木箱
        var crate := _mk_mat(Color(0.55, 0.4, 0.25))
        add_box(Vector3(8, 0.75, 6), Vector3(1.5, 1.5, 1.5), crate)
        add_box(Vector3(8, 2.0, 6), Vector3(1.2, 1.0, 1.2), crate, 0.5)
        add_box(Vector3(-10, 0.75, 10), Vector3(1.5, 1.5, 1.5), crate, 0.3)
        add_box(Vector3(14, 0.75, -8), Vector3(1.5, 1.5, 1.5), crate, 0.8)
        add_box(Vector3(-3, 0.75, -12), Vector3(1.5, 1.5, 1.5), crate)
        # 油桶
        var barrel := _mk_mat(Color(0.3, 0.5, 0.35), 0.6)
        for p in [Vector3(4, 0.6, 18), Vector3(-18, 0.6, -4), Vector3(20, 0.6, 14)]:
                var body := StaticBody3D.new()
                var mi := MeshInstance3D.new()
                var mesh := CylinderMesh.new()
                mesh.top_radius = 0.45
                mesh.bottom_radius = 0.45
                mesh.height = 1.2
                mi.mesh = mesh
                mi.material_override = barrel
                mi.position = p
                body.add_child(mi)
                var cs := CollisionShape3D.new()
                var shape := CylinderShape3D.new()
                shape.radius = 0.45
                shape.height = 1.2
                cs.shape = shape
                cs.position = p
                body.add_child(cs)
                add_child(body)
        # 岩石
        var rock := _mk_mat(Color(0.45, 0.44, 0.42))
        for e in [[6.0, -3.0], [-8.0, 5.0], [3.0, 9.0], [-4.0, -10.0], [12.0, 6.0], [-12.0, -6.0], [9.0, -12.0], [-6.0, 13.0]]:
                var s := randf_range(0.8, 1.6)
                add_box(Vector3(e[0], s * 0.3, e[1]), Vector3(s, s * 0.6, s * 1.2), rock, randf() * PI)


# ---------------- 玩家 ----------------
func _setup_player() -> void:
        player = PlayerScript.new()
        player.position = Vector3(0, 0.3, 10)
        add_child(player)
        player.died.connect(_on_player_died)


# ---------------- UI ----------------
func _mk_label(text: String, fsize: int, color := Color.WHITE) -> Label:
        var l := Label.new()
        l.text = text
        l.add_theme_font_override("font", FONT)
        l.add_theme_font_size_override("font_size", fsize)
        l.add_theme_color_override("font_color", color)
        l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
        l.add_theme_constant_override("outline_size", 6)
        l.mouse_filter = Control.MOUSE_FILTER_IGNORE
        return l


func _mk_button(text: String, fsize: int) -> Button:
        var b := Button.new()
        b.text = text
        b.add_theme_font_override("font", FONT)
        b.add_theme_font_size_override("font_size", fsize)
        b.add_theme_color_override("font_color", Color.WHITE)
        b.add_theme_color_override("font_pressed_color", Color(1, 0.9, 0.4))
        b.focus_mode = Control.FOCUS_NONE
        var sb := StyleBoxFlat.new()
        sb.bg_color = Color(1, 1, 1, 0.14)
        sb.set_corner_radius_all(45)
        b.add_theme_stylebox_override("normal", sb)
        b.add_theme_stylebox_override("hover", sb)
        var sb2 := sb.duplicate()
        sb2.bg_color = Color(1, 1, 1, 0.3)
        b.add_theme_stylebox_override("pressed", sb2)
        return b


# ---------- 程序化图标 ----------
class IconDraw extends Control:
        var kind := "fire"
        func _draw() -> void:
                var d := size.x
                var c := size / 2.0
                var col := Color(1, 1, 1, 0.95)
                match kind:
                        "fire":
                                draw_arc(c, d * 0.26, 0, TAU, 32, col, d * 0.055)
                                for a in [0.0, PI * 0.5, PI, PI * 1.5]:
                                        var dir := Vector2.from_angle(a)
                                        draw_line(c + dir * d * 0.38, c + dir * d * 0.52, col, d * 0.055)
                                draw_circle(c, d * 0.07, col)
                        "jump":
                                var pts := PackedVector2Array([Vector2(d * 0.24, d * 0.62), Vector2(d * 0.5, d * 0.32), Vector2(d * 0.76, d * 0.62)])
                                draw_polyline(pts, col, d * 0.08)
                                draw_circle(pts[0], d * 0.055, col)
                                draw_circle(pts[2], d * 0.055, col)
                        "ads":
                                draw_arc(c, d * 0.32, 0, TAU, 32, col, d * 0.05)
                                for a in [0.0, PI * 0.5, PI, PI * 1.5]:
                                        var dir := Vector2.from_angle(a)
                                        draw_line(c + dir * d * 0.10, c + dir * d * 0.46, col, d * 0.045)
                                draw_circle(c, d * 0.08, col)
                        "reload":
                                draw_arc(c, d * 0.28, -PI * 0.75, PI * 0.85, 24, col, d * 0.07)
                                var tip := c + Vector2.from_angle(PI * 0.85) * d * 0.28
                                var tan := Vector2.from_angle(PI * 0.85 + PI * 0.5)
                                draw_colored_polygon(PackedVector2Array([tip + tan * d * 0.13, tip - Vector2.from_angle(PI * 0.85) * d * 0.10 + tan * d * 0.04, tip - Vector2.from_angle(PI * 0.85) * d * 0.10 - tan * d * 0.04]), col)
                        "settings":
                                for i in 3:
                                        var y := d * (0.30 + 0.20 * i)
                                        draw_line(Vector2(d * 0.18, y), Vector2(d * 0.82, y), col, d * 0.05)
                                        draw_circle(Vector2(d * (0.62 - 0.22 * i), y), d * 0.085, Color(0.15, 0.16, 0.2))
                                        draw_circle(Vector2(d * (0.62 - 0.22 * i), y), d * 0.055, col)


func _mk_icon_button(d: int, kind: String, a := 0.14) -> Button:
        var b := Button.new()
        b.text = ""
        b.focus_mode = Control.FOCUS_NONE
        var sb := StyleBoxFlat.new()
        sb.bg_color = Color(1, 1, 1, a)
        sb.set_corner_radius_all(int(d * 0.5))
        b.add_theme_stylebox_override("normal", sb)
        b.add_theme_stylebox_override("hover", sb)
        var sb2 := sb.duplicate()
        sb2.bg_color = Color(1, 1, 1, minf(a + 0.16, 0.6))
        b.add_theme_stylebox_override("pressed", sb2)
        var icon := IconDraw.new()
        icon.kind = kind
        icon.set_anchors_preset(Control.PRESET_FULL_RECT)
        icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
        b.add_child(icon)
        return b


func _mk_circle_panel(d: int, a: float) -> Panel:
        var p := Panel.new()
        p.size = Vector2(d, d)
        p.mouse_filter = Control.MOUSE_FILTER_IGNORE
        var sb := StyleBoxFlat.new()
        sb.bg_color = Color(1, 1, 1, a)
        sb.set_corner_radius_all(int(d * 0.5))
        p.add_theme_stylebox_override("panel", sb)
        return p


func _setup_ui() -> void:
        hud = Control.new()
        hud.set_anchors_preset(Control.PRESET_FULL_RECT)
        hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
        add_child(hud)

        hurt_rect = ColorRect.new()
        hurt_rect.color = Color(1, 0, 0, 0)
        hurt_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
        hurt_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
        hud.add_child(hurt_rect)

        info_label = _mk_label("", 22)
        info_label.position = Vector2(74, 18)
        hud.add_child(info_label)

        ammo_label = _mk_label("30 / 30", 26, Color(1, 0.95, 0.7))
        ammo_label.set_anchors_preset(Control.PRESET_TOP_RIGHT)
        ammo_label.offset_left = -220
        ammo_label.offset_top = 10
        ammo_label.offset_right = -16
        ammo_label.offset_bottom = 52
        ammo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
        hud.add_child(ammo_label)

        hp_bar = ProgressBar.new()
        hp_bar.min_value = 0
        hp_bar.max_value = 100
        hp_bar.value = 100
        hp_bar.show_percentage = false
        hp_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
        hp_bar.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
        hp_bar.offset_left = -190
        hp_bar.offset_top = -34
        hp_bar.offset_right = 190
        hp_bar.offset_bottom = -14
        var sb_bg := StyleBoxFlat.new()
        sb_bg.bg_color = Color(0, 0, 0, 0.5)
        sb_bg.set_corner_radius_all(8)
        hp_bar.add_theme_stylebox_override("background", sb_bg)
        var sb_fill := StyleBoxFlat.new()
        sb_fill.bg_color = Color(0.3, 0.85, 0.35)
        sb_fill.set_corner_radius_all(8)
        hp_bar.add_theme_stylebox_override("fill", sb_fill)
        hud.add_child(hp_bar)

        reload_tip = _mk_label("换弹中…", 24, Color(1, 0.85, 0.3))
        reload_tip.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
        reload_tip.offset_left = -100
        reload_tip.offset_top = -70
        reload_tip.offset_right = 100
        reload_tip.offset_bottom = -40
        reload_tip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        reload_tip.visible = false
        hud.add_child(reload_tip)

        wave_tip = _mk_label("", 40, Color(1, 0.95, 0.5))
        wave_tip.set_anchors_preset(Control.PRESET_CENTER)
        wave_tip.offset_left = -300
        wave_tip.offset_top = -140
        wave_tip.offset_right = 300
        wave_tip.offset_bottom = -80
        wave_tip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        wave_tip.modulate.a = 0.0
        hud.add_child(wave_tip)

        # 按钮
        # 操作按钮（图标版）
        btn_fire = _mk_icon_button(160, "fire", 0.18)
        btn_fire.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
        btn_fire.offset_left = -190
        btn_fire.offset_top = -200
        btn_fire.offset_right = -30
        btn_fire.offset_bottom = -40
        btn_fire.mouse_filter = Control.MOUSE_FILTER_IGNORE   # 由 _input 统一处理（支持拖动转视角）
        hud.add_child(btn_fire)

        btn_jump = _mk_icon_button(90, "jump")
        btn_jump.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
        btn_jump.offset_left = -310
        btn_jump.offset_top = -120
        btn_jump.offset_right = -220
        btn_jump.offset_bottom = -30
        btn_jump.pressed.connect(player.try_jump)
        hud.add_child(btn_jump)

        btn_ads = _mk_icon_button(90, "ads")
        btn_ads.toggle_mode = true
        btn_ads.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
        btn_ads.offset_left = -190
        btn_ads.offset_top = -310
        btn_ads.offset_right = -100
        btn_ads.offset_bottom = -220
        btn_ads.toggled.connect(func(on): player.set_ads(on))
        hud.add_child(btn_ads)

        btn_reload = _mk_icon_button(90, "reload")
        btn_reload.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
        btn_reload.offset_left = -310
        btn_reload.offset_top = -240
        btn_reload.offset_right = -220
        btn_reload.offset_bottom = -150
        btn_reload.pressed.connect(player.start_reload)
        hud.add_child(btn_reload)

        # 左上角设置
        btn_settings = _mk_icon_button(48, "settings", 0.20)
        btn_settings.position = Vector2(14, 12)
        btn_settings.pressed.connect(_toggle_settings)
        hud.add_child(btn_settings)
        _build_settings_panel()

        # 摇杆视觉
        joy_base = _mk_circle_panel(120, 0.10)
        joy_base.visible = false
        hud.add_child(joy_base)
        joy_knob = _mk_circle_panel(56, 0.28)
        joy_knob.position = Vector2(32, 32)
        joy_base.add_child(joy_knob)

        # 死亡界面
        death_ui = Control.new()
        death_ui.set_anchors_preset(Control.PRESET_FULL_RECT)
        death_ui.visible = false
        add_child(death_ui)
        var dim := ColorRect.new()
        dim.color = Color(0, 0, 0, 0.65)
        dim.set_anchors_preset(Control.PRESET_FULL_RECT)
        death_ui.add_child(dim)
        var big := _mk_label("你阵亡了", 52, Color(1, 0.35, 0.3))
        big.set_anchors_preset(Control.PRESET_CENTER)
        big.offset_left = -300
        big.offset_top = -150
        big.offset_right = 300
        big.offset_bottom = -80
        big.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        death_ui.add_child(big)
        death_stats = _mk_label("", 26)
        death_stats.set_anchors_preset(Control.PRESET_CENTER)
        death_stats.offset_left = -300
        death_stats.offset_top = -60
        death_stats.offset_right = 300
        death_stats.offset_bottom = -20
        death_stats.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        death_ui.add_child(death_stats)
        var again := _mk_button("再来一局", 30)
        again.set_anchors_preset(Control.PRESET_CENTER)
        again.offset_left = -110
        again.offset_top = 30
        again.offset_right = 110
        again.offset_bottom = 95
        again.pressed.connect(func(): get_tree().reload_current_scene())
        death_ui.add_child(again)


# ---------------- 触屏输入 ----------------
func _is_over_ui(pos: Vector2) -> bool:
        for b in [btn_jump, btn_ads, btn_reload, btn_settings]:
                if b.get_global_rect().has_point(pos):
                        return true
        return false


func _apply_look(dv: Vector2) -> void:
        var sens: float = 0.0035 * sens_mult * (0.55 if player.ads_on else 1.0)
        player.yaw -= dv.x * sens
        player.pitch = clampf(player.pitch - dv.y * sens, -1.35, 1.35)


func _input(event: InputEvent) -> void:
        if state != "playing":
                return
        if settings_panel.visible:
                return
        if event is InputEventScreenTouch:
                if event.pressed:
                        # 开火键按下：开火 + 该手指可拖动转视角（主流手感）
                        if btn_fire.get_global_rect().has_point(event.position):
                                player.firing = true
                                fire_look_id = event.index
                                fire_look_last = event.position
                                return
                        if _is_over_ui(event.position):
                                return
                        var vw := get_viewport().get_visible_rect().size
                        if event.position.x < vw.x * 0.45 and joy_id == -1:
                                joy_id = event.index
                                joy_center = event.position
                                joy_vec = Vector2.ZERO
                                joy_base.visible = true
                                joy_base.position = event.position - Vector2(60, 60)
                        elif look_id == -1:
                                look_id = event.index
                                look_last = event.position
                else:
                        if event.index == fire_look_id:
                                fire_look_id = -1
                                player.firing = false
                        if event.index == joy_id:
                                joy_id = -1
                                joy_vec = Vector2.ZERO
                                joy_base.visible = false
                                joy_knob.position = Vector2(32, 32)
                        elif event.index == look_id:
                                look_id = -1
        elif event is InputEventScreenDrag:
                if event.index == joy_id:
                        var d: Vector2 = event.position - joy_center
                        if d.length() > 48:
                                d = d.normalized() * 48.0
                        joy_vec = d / 48.0
                        joy_knob.position = Vector2(60, 60) + d - Vector2(28, 28)
                elif event.index == fire_look_id:
                        _apply_look(event.position - fire_look_last)
                        fire_look_last = event.position
                elif event.index == look_id:
                        _apply_look(event.position - look_last)
                        look_last = event.position


# ---------------- 设置 ----------------
func _toggle_settings() -> void:
        settings_panel.visible = not settings_panel.visible
        if not settings_panel.visible:
                _save_settings()


func _build_settings_panel() -> void:
        settings_panel = Panel.new()
        settings_panel.set_anchors_preset(Control.PRESET_CENTER)
        settings_panel.offset_left = -300
        settings_panel.offset_top = -190
        settings_panel.offset_right = 300
        settings_panel.offset_bottom = 190
        settings_panel.visible = false
        var sb := StyleBoxFlat.new()
        sb.bg_color = Color(0.08, 0.09, 0.13, 0.96)
        sb.set_corner_radius_all(22)
        settings_panel.add_theme_stylebox_override("panel", sb)
        hud.add_child(settings_panel)

        var title := _mk_label("设 置", 32, Color(1, 0.95, 0.6))
        title.position = Vector2(0, 18)
        title.size = Vector2(600, 40)
        title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        settings_panel.add_child(title)

        var close := Button.new()
        close.text = "×"
        close.focus_mode = Control.FOCUS_NONE
        close.add_theme_font_override("font", FONT)
        close.add_theme_font_size_override("font_size", 30)
        close.add_theme_color_override("font_color", Color.WHITE)
        close.flat = true
        close.position = Vector2(540, 12)
        close.size = Vector2(48, 48)
        close.pressed.connect(_toggle_settings)
        settings_panel.add_child(close)

        # 陀螺仪瞄准
        var lbl1 := _mk_label("陀螺仪瞄准", 26)
        lbl1.position = Vector2(36, 96)
        lbl1.size = Vector2(300, 36)
        settings_panel.add_child(lbl1)
        chk_gyro = CheckButton.new()
        chk_gyro.position = Vector2(480, 86)
        chk_gyro.size = Vector2(80, 50)
        chk_gyro.button_pressed = gyro_on
        chk_gyro.toggled.connect(func(on):
                gyro_on = on
                _save_settings())
        settings_panel.add_child(chk_gyro)

        # 灵敏度
        var lbl2 := _mk_label("灵敏度", 26)
        lbl2.position = Vector2(36, 186)
        lbl2.size = Vector2(160, 36)
        settings_panel.add_child(lbl2)
        sens_lbl = _mk_label("x%.2f" % sens_mult, 24, Color(1, 0.9, 0.5))
        sens_lbl.position = Vector2(196, 186)
        sens_lbl.size = Vector2(120, 36)
        settings_panel.add_child(sens_lbl)
        slider_sens = HSlider.new()
        slider_sens.min_value = 0.3
        slider_sens.max_value = 2.5
        slider_sens.step = 0.05
        slider_sens.value = sens_mult
        slider_sens.position = Vector2(36, 236)
        slider_sens.size = Vector2(528, 36)
        slider_sens.value_changed.connect(func(v):
                sens_mult = v
                sens_lbl.text = "x%.2f" % v)
        slider_sens.drag_ended.connect(func(_c): _save_settings())
        settings_panel.add_child(slider_sens)

        var hint := _mk_label("提示：开火键上滑动可一边射击一边转视角", 20, Color(1, 1, 1, 0.55))
        hint.position = Vector2(36, 316)
        hint.size = Vector2(540, 30)
        settings_panel.add_child(hint)


func _load_settings() -> void:
        var cf := ConfigFile.new()
        if cf.load("user://settings.cfg") == OK:
                gyro_on = cf.get_value("s", "gyro", false)
                sens_mult = cf.get_value("s", "sens", 1.0)


func _save_settings() -> void:
        var cf := ConfigFile.new()
        cf.set_value("s", "gyro", gyro_on)
        cf.set_value("s", "sens", sens_mult)
        cf.save("user://settings.cfg")


# ---------------- 波次 ----------------
func start_wave(n: int) -> void:
        wave = n
        to_spawn = mini(4 + n * 2, 16)
        spawn_timer = 0.8
        show_wave_tip("第 %d 波 · %d 只敌人" % [n, to_spawn])


func alive_count() -> int:
        return get_tree().get_nodes_in_group("enemies").size()


func spawn_enemy() -> void:
        var pos := _pick_spawn()
        var e: Node3D = EnemyScript.new()
        e.player = player
        e.max_hp = 100.0 + wave * 12.0
        e.hp = e.max_hp
        e.speed = minf(2.4 + wave * 0.12, 3.8)
        e.dmg = 12.0
        e.position = pos
        e.died.connect(_on_enemy_died)
        add_child(e)


func _pick_spawn() -> Vector3:
        for i in 8:
                var p: Vector2 = SPAWN_POINTS[randi() % SPAWN_POINTS.size()]
                var v := Vector3(p.x + randf_range(-1.5, 1.5), 0.3, p.y + randf_range(-1.5, 1.5))
                if v.distance_to(player.global_position) > 10.0:
                        return v
        return Vector3(0, 0.3, -22)


func _on_enemy_died(pos: Vector3) -> void:
        kills += 1
        if randf() < 0.22:
                _make_medkit(Vector3(pos.x, 0, pos.z))


func show_wave_tip(text: String) -> void:
        wave_tip.text = text
        wave_tip.modulate.a = 1.0
        wave_tip_t = 2.2


func _on_player_died() -> void:
        state = "dead"
        player.firing = false
        death_stats.text = "击杀 %d · 存活到第 %d 波" % [kills, wave]
        death_ui.visible = true


# ---------------- 医疗包 ----------------
func _make_medkit(pos: Vector3) -> void:
        var g := Node3D.new()
        var white := _mk_mat(Color(0.92, 0.92, 0.9), 0.5)
        var red := _mk_mat(Color(0.88, 0.2, 0.2), 0.5)
        var b := MeshInstance3D.new()
        var bm := BoxMesh.new()
        bm.size = Vector3(0.5, 0.34, 0.5)
        b.mesh = bm
        b.material_override = white
        g.add_child(b)
        for s in [[0.3, 0.36, 0.1], [0.1, 0.36, 0.3]]:
                var c := MeshInstance3D.new()
                var cm := BoxMesh.new()
                cm.size = Vector3(s[0], s[1], s[2])
                c.mesh = cm
                c.material_override = red
                g.add_child(c)
        g.position = pos + Vector3(0, 0.35, 0)
        add_child(g)
        medkits.append({"node": g, "t": 0.0, "life": 9.0})


# ---------------- 每帧 ----------------
func _process(dt: float) -> void:
        # 陀螺仪瞄准（横屏试验映射：转手机=转视角；触摸屏幕时暂停）
        if gyro_on and state == "playing" and not settings_panel.visible \
                        and look_id == -1 and fire_look_id == -1 and joy_id == -1:
                var g: Vector3 = Input.get_gyroscope()
                if g.length() > 0.0001:
                        player.yaw -= g.x * dt * 1.2 * sens_mult
                        player.pitch = clampf(player.pitch - g.y * dt * 1.2 * sens_mult, -1.35, 1.35)
        # 开火键按压反馈
        btn_fire.modulate.a = 1.0 if (state == "playing" and player.firing) else 0.72
        if wave_tip_t > 0:
                wave_tip_t -= dt
                wave_tip.modulate.a = clampf(wave_tip_t / 0.5, 0.0, 1.0)
        if hurt_a > 0:
                hurt_a = maxf(hurt_a - dt * 1.5, 0.0)
                hurt_rect.color.a = hurt_a
        # 医疗包
        for i in range(medkits.size() - 1, -1, -1):
                var mk: Dictionary = medkits[i]
                var node: Node3D = mk.node
                mk.t += dt
                node.rotation.y += dt * 2.0
                node.position.y = 0.35 + sin(mk.t * 3.0) * 0.08
                var rest: float = mk.life - mk.t
                if rest < 2.0:
                        node.visible = fmod(mk.t * 5.0, 2.0) < 1.2
                if player and player.global_position.distance_to(node.global_position) < 1.4 and player.hp > 0:
                        player.heal(35.0)
                        node.queue_free()
                        medkits.remove_at(i)
                        continue
                if rest <= 0:
                        node.queue_free()
                        medkits.remove_at(i)


func _physics_process(dt: float) -> void:
        if state != "playing":
                return
        player.move_dir = joy_vec
        # 血条 & 受击红闪
        hp_bar.value = player.hp
        var fill: StyleBoxFlat = hp_bar.get_theme_stylebox("fill")
        if player.hp < 30:
                fill.bg_color = Color(0.9, 0.25, 0.25)
        if player.hp < prev_hp:
                hurt_a = 0.35
        prev_hp = player.hp
        # 出怪
        spawn_timer -= dt
        if to_spawn > 0 and spawn_timer <= 0 and alive_count() < 10:
                spawn_enemy()
                to_spawn -= 1
                spawn_timer = 0.6
        elif to_spawn == 0 and alive_count() == 0:
                if wave_clear_t < 0:
                        wave_clear_t = 3.0
                        show_wave_tip("肃清！3 秒后下一波")
                else:
                        wave_clear_t -= dt
                        if wave_clear_t <= 0:
                                wave_clear_t = -1.0
                                start_wave(wave + 1)
        # HUD
        info_label.text = "击杀 %d · 第 %d 波 · 剩余 %d" % [kills, wave, to_spawn + alive_count()]
        ammo_label.text = "%d / %d" % [player.ammo, player.mag]
        reload_tip.visible = player.reloading
