extends CharacterBody3D
# 敌人：追击（带游走）→ 近身攻击 → 死亡倒地淡出

signal died(pos: Vector3)

const GRAVITY := 20.0
const FONT = preload("res://fonts/ui.otf")

var max_hp := 114.0
var hp := 114.0
var speed := 2.6
var dmg := 12.0
var alive := true
var state := "chase"          # chase / attack / dying
var t := 0.0
var seed_n := 0.0
var attack_t := 0.0
var did_hit := false
var dying_t := 0.0
var flash_t := 0.0
var player: Node3D
var body_mat: StandardMaterial3D
var head_mat: StandardMaterial3D


func _ready() -> void:
        add_to_group("enemies")
        seed_n = randf() * 10.0
        body_mat = StandardMaterial3D.new()
        body_mat.albedo_color = Color(0.35, 0.42, 0.28)
        body_mat.roughness = 1.0
        body_mat.emission_enabled = true
        body_mat.emission = Color(0, 0, 0)
        head_mat = StandardMaterial3D.new()
        head_mat.albedo_color = Color(0.72, 0.58, 0.42)
        head_mat.roughness = 0.9
        head_mat.emission_enabled = true
        head_mat.emission = Color(0, 0, 0)

        var cs := CollisionShape3D.new()
        var shape := CapsuleShape3D.new()
        shape.radius = 0.4
        shape.height = 1.9
        cs.shape = shape
        cs.position = Vector3(0, 0.95, 0)
        add_child(cs)

        _torso_part(CapsuleMesh.new(), body_mat, Vector3(0.38, 0.85, 0.38), Vector3(0, 1.15, 0))
        _torso_part(SphereMesh.new(), head_mat, Vector3(0.56, 0.56, 0.56), Vector3(0, 1.95, 0))
        # 红眼
        var eye := StandardMaterial3D.new()
        eye.albedo_color = Color(1, 0.15, 0.1)
        eye.emission_enabled = true
        eye.emission = Color(0.8, 0.08, 0.05)
        for s in [-1.0, 1.0]:
                _torso_part(SphereMesh.new(), eye, Vector3(0.09, 0.09, 0.09), Vector3(0.09 * s, 2.0, 0.24))
        # 手臂
        for s in [-1.0, 1.0]:
                var arm := _torso_part(CapsuleMesh.new(), body_mat, Vector3(0.16, 0.7, 0.16), Vector3(0.48 * s, 1.3, 0))
                arm.rotation.z = 0.18 * s
        # 腿
        for s in [-1.0, 1.0]:
                var _leg := _torso_part(CapsuleMesh.new(), body_mat, Vector3(0.18, 0.6, 0.18), Vector3(0.17 * s, 0.42, 0))


func _torso_part(mesh: Mesh, m: Material, size: Vector3, pos: Vector3) -> MeshInstance3D:
        mesh.radius = size.x * 0.5
        mesh.height = size.y
        var mi := MeshInstance3D.new()
        mi.mesh = mesh
        mi.material_override = m
        mi.position = pos
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
        add_child(mi)
        return mi


func take_damage(amount: float, hit_pos: Vector3, head: bool) -> void:
        if not alive:
                return
        hp -= amount
        flash_t = 0.14
        _float_text(hit_pos, str(int(amount)), Color(1.0, 0.85, 0.2) if head else Color.WHITE)
        if hp <= 0:
                _die()


func _die() -> void:
        alive = false
        state = "dying"
        dying_t = 0.0
        remove_from_group("enemies")
        collision_layer = 0
        collision_mask = 1
        died.emit(global_position)
        _float_text(global_position + Vector3(0, 2.3, 0), "击杀", Color(1, 0.3, 0.25))


func _float_text(pos: Vector3, text: String, color: Color) -> void:
        var l := Label3D.new()
        l.text = text
        l.font = FONT
        l.font_size = 52
        l.pixel_size = 0.005
        l.outline_size = 10
        l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
        l.modulate = color
        l.position = pos
        get_parent().add_child(l)
        var tw := l.create_tween()
        tw.tween_property(l, "position:y", pos.y + 1.2, 0.7)
        tw.parallel().tween_property(l, "modulate:a", 0.0, 0.7)
        tw.tween_callback(l.queue_free)


func _physics_process(dt: float) -> void:
        t += dt
        # 受击红闪
        if flash_t > 0:
                flash_t -= dt
                var on := flash_t > 0 and fmod(flash_t, 0.06) < 0.03
                body_mat.emission = Color(0.6, 0.08, 0.08) if on else Color(0, 0, 0)
                head_mat.emission = body_mat.emission
        # 死亡动画（倒地 → 下沉淡出）
        if state == "dying":
                dying_t += dt
                if dying_t < 0.5:
                        rotation.x = -(dying_t / 0.5) * PI / 2.0
                if dying_t > 1.1:
                        var k := maxf(1.0 - (dying_t - 1.1) / 0.7, 0.0)
                        body_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
                        head_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
                        body_mat.albedo_color.a = k
                        head_mat.albedo_color.a = k
                        position.y = -(1.0 - k) * 0.5
                        if k <= 0:
                                queue_free()
                return
        # 玩家阵亡后定格
        if player == null or not is_instance_valid(player) or player.hp <= 0:
                return
        var to_p: Vector3 = player.global_position - global_position
        to_p.y = 0
        var d := to_p.length()
        if state == "chase":
                var dir := to_p.normalized() if d > 0.01 else Vector3.ZERO
                # 路径游走，避免直线卡墙
                var wob := sin(t * 1.5 + seed_n) * 0.35
                var side := Vector3(-dir.z, 0, dir.x)
                var vdir := (dir + side * wob).normalized()
                velocity.x = vdir.x * speed
                velocity.z = vdir.z * speed
                if not is_on_floor():
                        velocity.y -= GRAVITY * dt
                # 同伴分离
                for o in get_tree().get_nodes_in_group("enemies"):
                        if o == self:
                                continue
                        var off: Vector3 = global_position - o.global_position
                        off.y = 0
                        var od := off.length()
                        if od < 1.0 and od > 0.01:
                                velocity.x += off.x / od * 2.0
                                velocity.z += off.z / od * 2.0
                if d > 0.01:
                        rotation.y = atan2(dir.x, dir.z)
                move_and_slide()
                if d < 1.9:
                        state = "attack"
                        attack_t = 0.0
                        did_hit = false
        elif state == "attack":
                velocity.x = 0
                velocity.z = 0
                if not is_on_floor():
                        velocity.y -= GRAVITY * dt
                move_and_slide()
                if d > 0.01:
                        rotation.y = atan2(to_p.x, to_p.z)
                attack_t += dt
                if attack_t >= 0.45 and not did_hit:
                        did_hit = true
                        if d < 2.3:
                                player.take_hit(dmg)
                if attack_t >= 1.0:
                        attack_t = 0.0
                        did_hit = false
                        if d >= 1.9:
                                state = "chase"
